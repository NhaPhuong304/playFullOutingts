<div class="footer text-center shadow-sm py-3 mt-5">
                <p class="m-0">Copyright © 2025. All Rights Reserved. <a href="https://www.templaterise.com/" class="text-primary" target="_blank" >Themes By TemplateRise</a></p>
            </div>