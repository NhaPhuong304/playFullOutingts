

<?php $__env->startSection('content'); ?>

<style>
    .summernote-content img {
        max-width: 100%;
        border-radius: 6px;
        margin: 10px 0;
    }

    .summernote-content p {
        line-height: 1.6;
        margin-bottom: 12px;
    }
</style>
<div class="container mt-4">

    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold"><?php echo e($blog->blog_name); ?></h3>

        <div>
            <a href="<?php echo e(route('admin.blog.index')); ?>" class="btn btn-secondary me-2">Back</a>
            <a href="<?php echo e(route('admin.blog.edit', $blog->id)); ?>" class="btn btn-warning me-2">Edit</a>

            <form action="<?php echo e(route('admin.blog.delete', $blog->id)); ?>" method="POST" class="d-inline"
                onsubmit="return confirm('Are you sure you want to delete this blog?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger">Delete</button>
            </form>
        </div>
    </div>

    
    <?php if($blog->image): ?>
    <div class="mb-4">
        <img src="<?php echo e(asset('storage/' . $blog->image)); ?>"
            class="img-fluid rounded shadow"
            style="max-height: 400px; object-fit: cover;">
    </div>
    <?php endif; ?>

    
    <div class="mb-3">
        <strong>Author:</strong>
        <span><?php echo e($blog->user->name ?? $blog->user->email ?? 'N/A'); ?></span>
    </div>

    <div class="mb-3">
        <strong>Posted Date:</strong>
        <span><?php echo e($blog->posted_date); ?></span>
    </div>

    
    <div class="card mt-4">
        <div class="card-header fw-bold">Content</div>
        <div class="card-body">

            
            <div class="summernote-content">
                <?php echo $blog->content; ?>

            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doan\doan\resources\views/admin/blog/show.blade.php ENDPATH**/ ?>