

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3 class="fw-bold mb-3">Edit Blog</h3>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.blog.update', $blog->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div class="mb-3">
            <label class="form-label">Blog Title</label>
            <input type="text" class="form-control" name="blog_name"
                value="<?php echo e(old('blog_name', $blog->blog_name)); ?>" required>
        </div>

        
        <div class="mb-3">
            <label class="form-label">Author</label>
            <select name="user_id" class="form-select" required>
                <option value="">-- Select User --</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($u->id); ?>" <?php echo e($blog->user_id == $u->id ? 'selected' : ''); ?>>
                        <?php echo e($u->name ?? $u->email); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-3">
            <label class="form-label">Blog Image</label>
            <input type="file" name="image" class="form-control" id="imageInput">

            <?php if($blog->image): ?>
                <div class="mt-2">
                    <p class="fw-bold mb-1">Current Image:</p>
                    <img src="<?php echo e(asset('storage/' . $blog->image)); ?>" width="150" class="rounded border" id="currentImage">
                </div>
            <?php endif; ?>

            <img id="previewImage" class="mt-2 rounded" width="150" style="display:none;">
        </div>

        
        <div class="mb-3">
            <label class="form-label">Content</label>
            <textarea name="content" id="summernote" class="form-control">
                <?php echo old('content', $blog->content); ?>

            </textarea>
        </div>

        <button class="btn btn-primary">Save Changes</button>
        <a href="<?php echo e(route('admin.blog.index')); ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>

<script>
$(document).ready(function() {
    // Summernote
    $('#summernote').summernote({
        placeholder: 'Write blog content here...',
        tabsize: 2,
        height: 350,
        toolbar: [
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['font', ['fontsize', 'color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['insert', ['picture', 'link', 'video']],
            ['view', ['fullscreen', 'codeview']]
        ]
    });

    // Image preview
    $('#imageInput').on('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            $('#previewImage').attr('src', URL.createObjectURL(file)).show();
            $('#currentImage').hide();
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doan\doan\resources\views/admin/blog/edit.blade.php ENDPATH**/ ?>