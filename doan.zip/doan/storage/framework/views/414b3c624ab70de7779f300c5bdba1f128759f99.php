<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>EcomPanel - Dashboard</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('admin/assets/favicon.ico')); ?>" type="image/x-icon" />

    <!-- CSS Local -->
    <link href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/css/style.css')); ?>" rel="stylesheet" />

    <!-- FontAwesome -->
    <link href="<?php echo e(asset('admin/assets/icons/fontawesome/css/fontawesome.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/icons/fontawesome/css/brands.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/icons/fontawesome/css/solid.min.css')); ?>" rel="stylesheet" />

    <!-- Bootstrap Icons CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" />

    <!-- Stack for page-specific styles -->
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="spinner"></div>
    </div>

    <!-- Main Wrapper -->
    <div id="main-wrapper" class="d-flex">

        <!-- Sidebar -->
        <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Header -->
        <?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <?php echo $__env->yieldContent('content'); ?>

            <!-- Footer -->
            <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <!-- JS Local -->
    <script src="<?php echo e(asset('admin/assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/chart.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/main.js')); ?>"></script>

    <!-- Stack for page-specific scripts -->
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\doan\doan\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>